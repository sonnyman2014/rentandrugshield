const PRIMARY_AUDIT_URL = 'https://rentandrugshield.com/api/audit';
const LIVE_EP_URL = 'https://rentandrugshield.com/live_endpoint.json';
const FALLBACK_TUNNEL = 'https://proceeding-pavilion-brunswick-wherever.trycloudflare.com';
const RUGGED_MINT = '8zaYjmVacfAnMhf3cLsECgzK6pLtWrLQbBv65y3vjyR1';

function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

async function resolveApiBase() {
  try {
    const r = await fetch(LIVE_EP_URL + '?t=' + Date.now(), { cache: 'no-store' });
    if (r.ok) {
      const j = await r.json();
      const b = String((j && (j.api_base || j.endpoint)) || '').replace(/\/+$/, '');
      if (b.startsWith('https://')) return b;
    }
  } catch (_e) {}
  return FALLBACK_TUNNEL;
}

async function postJson(path, body) {
  const base = await resolveApiBase();
  const urls = path === '/api/audit' ? [base + '/api/audit', PRIMARY_AUDIT_URL] : [base + path];
  for (const u of urls) {
    try {
      const r = await fetch(u, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
      const d = await r.json();
      if (r.ok || d.score !== undefined || d.ok !== undefined) return d;
    } catch (_e) {}
  }
  throw new Error('Scanner unreachable');
}

function extractMint(urlStr) {
  const m = String(urlStr || '').match(/[1-9A-HJ-NP-Za-km-z]{32,44}/g) || [];
  return m.find((c) => c !== 'So11111111111111111111111111111111111111112') || '';
}

async function auditMint(mintOverride, isSample) {
  const inp = document.getElementById('ext-mint-inp');
  const out = document.getElementById('ext-mint-out');
  const mint = (mintOverride || inp.value || '').trim();
  if (!mint) { out.style.display = 'block'; out.textContent = 'Paste a Solana mint address first.'; return; }
  inp.value = mint;
  out.style.display = 'block';
  out.textContent = 'Scanning 11 layers via rentandrugshield.com/api/audit…';
  try {
    const d = await postJson('/api/audit', { mint, source: isSample ? 'free_test_rugged' : 'chrome_ext', is_sample_test: !!isSample });
    const score = d.safety_score !== undefined ? d.safety_score : (d.score !== undefined ? d.score : 0);
    const col = score >= 80 ? '#3DDC97' : (score >= 50 ? '#FFB547' : '#FF5C5C');
    const checks = Array.isArray(d.checks) ? d.checks.slice(0, 4).map((c) => (c.passed ? '✓ ' : '✕ ') + esc((c.label || c.name) + ': ' + (c.detail || c.status || ''))).join('<br>') : '';
    out.innerHTML = `<div style="color:${col};font-weight:700">Score ${Number(score)}/100 · ${esc(d.verdict || 'Audited')}</div><div style="margin-top:4px;color:#A3A8B3">${checks}</div>`;
  } catch (_e) {
    out.innerHTML = '<span style="color:#FF5C5C">Could not reach live /api/audit endpoint.</span>';
  }
}

async function previewWallet() {
  const inp = document.getElementById('ext-wallet-inp');
  const out = document.getElementById('ext-wallet-out');
  const wallet = (inp.value || '').trim();
  if (!wallet) { out.style.display = 'block'; out.textContent = 'Paste a Solana wallet address.'; return; }
  out.style.display = 'block';
  out.textContent = 'Reading empty token accounts…';
  try {
    const q = await postJson('/api/reclaim-fee-quote', { wallet });
    if (!q.ok) throw new Error(q.error || 'Failed');
    const net = (Number(q.user_net_lamports || 0) / 1e9).toFixed(5);
    const cnt = Number(q.rows_total || q.accounts || 0);
    out.innerHTML = `<div style="color:#3DDC97;font-weight:700">${cnt} accounts · +${net} SOL net</div><div style="margin-top:4px"><a href="https://rentandrugshield.com/app?wallet=${encodeURIComponent(wallet)}" target="_blank" rel="noopener" style="color:#F4F5F7">Open non-custodial reclaim ↗</a></div>`;
  } catch (_e) {
    out.innerHTML = '<span style="color:#FF5C5C">Could not scan wallet right now.</span>';
  }
}

document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('ext-audit-btn').addEventListener('click', () => auditMint('', false));
  document.getElementById('ext-rugged-btn').addEventListener('click', () => auditMint(RUGGED_MINT, true));
  document.getElementById('ext-wallet-btn').addEventListener('click', previewWallet);
  if (typeof chrome !== 'undefined' && chrome.tabs && chrome.tabs.query) {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const det = tabs && tabs[0] && extractMint(tabs[0].url);
      if (det) { document.getElementById('tab-badge').textContent = 'Tab mint detected'; auditMint(det, false); }
    });
  }
});
