========================================================================
🛡️ SOL RENT & RUG SHIELD — OFFICIAL CHROME / BRAVE MV3 EXTENSION (v4.1.0)
========================================================================
How to Pin Right Next to Phantom Wallet in 10 Seconds:

1. OPEN CHROME EXTENSIONS:
   Copy and paste into your Chrome / Brave / Edge address bar:
   chrome://extensions
   Turn ON "Developer mode" (toggle switch in the top-right corner).

2. CLICK "LOAD UNPACKED":
   - On Windows: Select C:\SolanaRentRugShield_Extension (or your unzipped folder).
   - On Mac / Linux: Unzip CWS_READY_SolanaRentRugShield_MV3.zip and select that folder.

3. PIN NEXT TO PHANTOM:
   Click the 🧩 Extensions puzzle icon in your browser toolbar and click
   the 📌 Pin icon next to "SOL Rent & Rug Shield"!
========================================================================
