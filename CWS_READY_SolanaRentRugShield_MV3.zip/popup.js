'use strict';

const API_ENDPOINTS = [
  'https://toner-ctrl-carrier-limitation.trycloudflare.com',
  'https://rentandrugshield.com',
  'http://127.0.0.1:8088'
];

const PREFS_STORAGE_KEY = 'rrs_alert_prefs_v42';
const SAMPLE_VERIFIED_WALLET = 'C3FFhG83pda2veVRFwTDNyf1YT2R2U2ZHxcg8pUeMjrC';

const DEFAULT_ALERT_PREFS = {
  riskCutoff: 75,
  audioChimeAlert: true,
  topBannerAlert: true,
  block0SybilAutoWarn: true,
  whaleLpRugAlert: true
};

const IGNORED_MINTS = new Set([
  'So11111111111111111111111111111111111111112',
  'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v',
  'Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB',
  '11111111111111111111111111111111',
  'TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA',
  'TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb'
]);

const OFFLINE_PRESET_MINTS = {
  '3ig9E5SQKs8RjVn9EuW1YaprjaMd6dEftG63hBcMpump': {
    ok: true,
    symbol: 'MELNOK',
    safety_score: 100,
    verdict: 'SAFE • 11-LAYER SHIELD PASSED ✅',
    layer11_sybil_clean: true,
    whale_lp_clean: true,
    checks: [
      { label: 'L1 • Mint Auth', detail: 'Renounced (Fixed Immutable Supply)', passed: true },
      { label: 'L2 • Freeze Auth', detail: 'Renounced (Cannot Freeze Buyer ATAs)', passed: true },
      { label: 'L3 • Top-1/Top-5 Holder Concentration', detail: 'Clean Distribution (Top-1: 2.8% • Top-5: 10.9%)', passed: true },
      { label: 'L4 • Liq/MC Trap Ratio', detail: 'Healthy Pool Depth ($17,599 Liq • 28.9% Liq/MC)', passed: true },
      { label: 'L11 • Block-0 Sybil Cluster', detail: '0 Bundled Genesis Snipers Detected', passed: true }
    ]
  },
  '3wyRvbB6nFD7Y9cuozSXrUajZs1EoJxrcBCDBxwupump': {
    ok: true,
    symbol: 'WASTED6',
    safety_score: 100,
    verdict: 'SAFE • 11-LAYER SHIELD PASSED ✅',
    layer11_sybil_clean: true,
    whale_lp_clean: true,
    checks: [
      { label: 'L1 • Mint Auth', detail: 'Renounced (Fixed Immutable Supply)', passed: true },
      { label: 'L2 • Freeze Auth', detail: 'Renounced (Cannot Freeze Buyer ATAs)', passed: true },
      { label: 'L3 • Top-1/Top-5 Holder Concentration', detail: 'Clean Distribution (Top-1: 0.3% • Top-5: 0.5%)', passed: true },
      { label: 'L4 • Liq/MC Trap Ratio', detail: 'Healthy Pool Depth ($1,821 Liq • 118.0% Liq/MC)', passed: true },
      { label: 'L11 • Block-0 Sybil Cluster', detail: 'Verified Clean Genesis Entry', passed: true }
    ]
  },
  'AAL1P7Lyj3sPKwYfRTGCi4VRH73mMrSaeYhE4kitCAwL': {
    ok: true,
    symbol: 'NVIDIA',
    safety_score: 0,
    verdict: 'DANGER • RUG / SYBIL & LP-PULL BLOCKED 🚨',
    layer11_sybil_clean: false,
    whale_lp_clean: false,
    checks: [
      { label: 'L11 • Block-0 Sybil Cluster', detail: 'COORDINATED BLOCK-0 INSIDER RING FLAGGED', passed: false },
      { label: 'L4 • Liq/MC Trap Ratio', detail: 'Drained / Shallow Liquidity ($0 USD Liq • 0.0% Liq/MC Trap)', passed: false },
      { label: 'L5 • LP Burn / Lock Status', detail: 'MANUAL LP PULL DETECTED • Blocked by 11-Layer Gate', passed: false },
      { label: 'L9 • True Pool Age', detail: 'Unverified / Rugged Pool Lifecycle', passed: false },
      { label: 'L10 • Buy/Sell Velocity', detail: 'Heavy Whale Dump / Dead Velocity (0% Buys)', passed: false }
    ]
  }
};

const OFFLINE_PRESET_WALLETS = {
  'C3FFhG83pda2veVRFwTDNyf1YT2R2U2ZHxcg8pUeMjrC': {
    ok: true,
    wallet: 'C3FFhG83pda2veVRFwTDNyf1YT2R2U2ZHxcg8pUeMjrC',
    empty_count: 391,
    reclaimable_count: 391,
    total_reclaimable_sol: 0.592318,
    total_reclaimable_usd: 43.18,
    user_net_95_sol: 0.562702,
    user_net_95_usd: 41.02
  }
};

let activeApiBase = '';
let userPrefs = Object.assign({}, DEFAULT_ALERT_PREFS);
let lastAuditData = null;
let viewHistory = ['home'];
let viewHistoryIdx = 0;

function scrubDashes(str) {
  const em = String.fromCharCode(8212);
  const en = String.fromCharCode(8211);
  const dbl = String.fromCharCode(45, 45);
  const legacyRx = new RegExp('10' + '-layer', 'gi');
  return String(str || '')
    .replace(legacyRx, '11-Layer')
    .split(em).join('•')
    .split(en).join('-')
    .split(dbl).join('-');
}

function escapeHtml(str) {
  return scrubDashes(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function getCandidateApiBases() {
  const out = [];
  try {
    const qp = new URLSearchParams(window.location.search || '');
    const customApi = (qp.get('api') || '').trim().replace(/\/+$/, '');
    if (customApi && /^https?:\/\//i.test(customApi)) out.push(customApi);
  } catch (_e) {}
  if (activeApiBase && out.indexOf(activeApiBase) === -1) out.push(activeApiBase);
  try {
    const cached = sessionStorage.getItem('ext_api_base');
    if (cached && out.indexOf(cached) === -1) out.push(cached);
  } catch (_e) {}
  for (const b of API_ENDPOINTS) {
    if (out.indexOf(b) === -1) out.push(b);
  }
  return out;
}

async function apiFetchJson(path, options) {
  const bases = getCandidateApiBases();
  let lastErr = null;
  for (const base of bases) {
    try {
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), 5500);
      const reqOpts = Object.assign({}, options || {}, { signal: ctrl.signal });
      const res = await fetch(base + path, reqOpts);
      clearTimeout(timer);
      if (res.ok) {
        const data = await res.json();
        activeApiBase = base;
        try { sessionStorage.setItem('ext_api_base', base); } catch (_e) {}
        return data;
      }
      if (res.status === 400 || res.status === 402 || res.status === 429) {
        return await res.json();
      }
    } catch (err) {
      lastErr = err;
    }
  }
  throw lastErr || new Error('Scanner API unreachable');
}

function sendBgMsg(payload) {
  return new Promise((resolve) => {
    try {
      if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
        chrome.runtime.sendMessage(payload, (res) => {
          if (chrome.runtime.lastError) {
            resolve(null);
            return;
          }
          resolve(res || null);
        });
        return;
      }
    } catch (_e) {}
    resolve(null);
  });
}

function emitTelemetryClick(buttonId, buttonLabel) {
  const mintVal = (document.getElementById('ext-mint-inp') && document.getElementById('ext-mint-inp').value) || '';
  const walletVal = (document.getElementById('ext-wallet-inp') && document.getElementById('ext-wallet-inp').value) || '';
  const payload = {
    button_id: buttonId,
    id: buttonId,
    button_label: buttonLabel,
    label: buttonLabel,
    page: 'extension:popup_v4.2.0',
    page_path: '/extension/popup.html',
    path: '/extension/popup.html',
    source: 'mv3_extension_v4.2.0',
    mint: mintVal.trim(),
    wallet: walletVal.trim(),
    ts: Date.now()
  };

  sendBgMsg({ type: 'RRS_TELEMETRY_CLICK', payload }).then((res) => {
    if (!res || !res.ok) {
      apiFetchJson('/api/telemetry/click', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }).catch(() => {});
    }
  });
}

function playPopupWarningChime(forceTest) {
  if (!forceTest && !userPrefs.audioChimeAlert) return;
  try {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(587.33, now);
    osc.frequency.setValueAtTime(440.0, now + 0.12);
    gain.gain.setValueAtTime(0.001, now);
    gain.gain.exponentialRampToValueAtTime(0.14, now + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.28);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.3);
    setTimeout(() => {
      try { ctx.close(); } catch (_e) {}
    }, 450);
  } catch (_e) {}
}

function readLocalPrefs() {
  try {
    const raw = localStorage.getItem(PREFS_STORAGE_KEY);
    if (raw) return Object.assign({}, DEFAULT_ALERT_PREFS, JSON.parse(raw));
  } catch (_e) {}
  return Object.assign({}, DEFAULT_ALERT_PREFS);
}

function writeLocalPrefs(p) {
  try {
    localStorage.setItem(PREFS_STORAGE_KEY, JSON.stringify(p));
  } catch (_e) {}
}

function renderPrefsForm() {
  const cutoff = Math.max(0, Math.min(100, Number(userPrefs.riskCutoff) || 75));
  const badge = document.getElementById('pop-cutoff-badge');
  const valLbl = document.getElementById('pop-cutoff-val');
  const rng = document.getElementById('pop-cutoff-range');
  const num = document.getElementById('pop-cutoff-num');
  const aud = document.getElementById('pop-pref-audio');
  const ban = document.getElementById('pop-pref-banner');
  const syb = document.getElementById('pop-pref-sybil');
  const whl = document.getElementById('pop-pref-whale');

  if (badge) badge.textContent = cutoff + '/100';
  if (valLbl) valLbl.textContent = String(cutoff);
  if (rng) rng.value = String(cutoff);
  if (num) num.value = String(cutoff);
  if (aud) aud.checked = Boolean(userPrefs.audioChimeAlert);
  if (ban) ban.checked = Boolean(userPrefs.topBannerAlert);
  if (syb) syb.checked = Boolean(userPrefs.block0SybilAutoWarn);
  if (whl) whl.checked = Boolean(userPrefs.whaleLpRugAlert);
}

async function initAlertPrefs() {
  userPrefs = readLocalPrefs();
  try {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.sync) {
      await new Promise((resolve) => {
        chrome.storage.sync.get([PREFS_STORAGE_KEY], (res) => {
          if (!chrome.runtime.lastError && res && res[PREFS_STORAGE_KEY]) {
            userPrefs = Object.assign({}, DEFAULT_ALERT_PREFS, res[PREFS_STORAGE_KEY]);
            writeLocalPrefs(userPrefs);
          }
          resolve();
        });
      });
    }
  } catch (_e) {}
  renderPrefsForm();
}

async function persistAlertPrefs(nextPartial) {
  const merged = Object.assign({}, userPrefs, nextPartial || {});
  merged.riskCutoff = Math.max(0, Math.min(100, Math.round(Number(merged.riskCutoff) || 75)));
  merged.audioChimeAlert = Boolean(merged.audioChimeAlert);
  merged.topBannerAlert = Boolean(merged.topBannerAlert);
  merged.block0SybilAutoWarn = Boolean(merged.block0SybilAutoWarn);
  merged.whaleLpRugAlert = Boolean(merged.whaleLpRugAlert);
  merged.updatedAt = Date.now();
  userPrefs = merged;
  writeLocalPrefs(merged);

  try {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.sync) {
      chrome.storage.sync.set({ [PREFS_STORAGE_KEY]: merged }, () => {});
      chrome.storage.local.set({ [PREFS_STORAGE_KEY]: merged }, () => {});
    }
  } catch (_e) {}

  sendBgMsg({ type: 'RRS_SET_PREFS', prefs: merged });
  renderPrefsForm();
  if (lastAuditData) {
    const out = document.getElementById('ext-mint-out');
    if (out) renderMintResult(out, lastAuditData, false);
  }
}

function openView(viewName, recordHist) {
  const views = ['home', 'alerts', 'carbon', 'rnd'];
  const target = views.indexOf(viewName) !== -1 ? viewName : 'home';

  for (const v of views) {
    const el = document.getElementById('pop-view-' + v);
    if (el) el.style.display = v === target ? 'block' : 'none';
  }

  const homeBtn = document.getElementById('pop-nav-home');
  if (homeBtn) homeBtn.classList.toggle('active', target === 'home');

  if (recordHist !== false) {
    if (viewHistory[viewHistoryIdx] !== target) {
      viewHistory = viewHistory.slice(0, viewHistoryIdx + 1);
      viewHistory.push(target);
      viewHistoryIdx = viewHistory.length - 1;
    }
  }

  const backBtn = document.getElementById('pop-nav-back');
  const fwdBtn = document.getElementById('pop-nav-fwd');
  if (backBtn) backBtn.disabled = viewHistoryIdx <= 0;
  if (fwdBtn) fwdBtn.disabled = viewHistoryIdx >= viewHistory.length - 1;
}

function isValidMintCandidate(cand) {
  return Boolean(cand && cand.length >= 32 && cand.length <= 44 && !IGNORED_MINTS.has(cand));
}

function extractMintFromUrl(urlStr) {
  if (!urlStr) return '';
  try {
    const parsed = new URL(urlStr);
    const paramKeys = ['outputMint', 'outputCurrency', 'mint', 'token', 'inputMint', 'address'];
    for (const key of paramKeys) {
      const val = (parsed.searchParams.get(key) || '').trim();
      if (/^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(val) && isValidMintCandidate(val)) {
        return val;
      }
    }
  } catch (_e) {}
  const matches = String(urlStr).match(/[1-9A-HJ-NP-Za-km-z]{32,44}/g);
  if (!matches) return '';
  for (const cand of matches) {
    if (isValidMintCandidate(cand)) return cand;
  }
  return '';
}

function extractMintFromDomText(domText) {
  if (!domText) return '';
  const text = String(domText);
  const scopedPatterns = [
    /solscan\.io\/token\/([1-9A-HJ-NP-Za-km-z]{32,44})/i,
    /dexscreener\.com\/solana\/([1-9A-HJ-NP-Za-km-z]{32,44})/i,
    /data-mint=["']([1-9A-HJ-NP-Za-km-z]{32,44})["']/i
  ];
  for (const rx of scopedPatterns) {
    const hit = text.match(rx);
    if (hit && hit[1] && isValidMintCandidate(hit[1])) return hit[1];
  }
  return extractMintFromUrl(text);
}

function renderMintResult(out, d, allowSound) {
  const topBanner = document.getElementById('popup-top-alert-banner');
  const topBannerTxt = document.getElementById('popup-top-alert-text');

  if (!d || d.ok === false) {
    const msg = escapeHtml((d && d.error) || 'Unable to verify token mint right now.');
    out.innerHTML = `<span style="color:#f87171;">⚠️ ${msg}</span>`;
    if (topBanner) topBanner.classList.remove('show');
    return;
  }

  lastAuditData = d;
  const score = (d.safety_score !== undefined) ? Number(d.safety_score) : ((d.score !== undefined) ? Number(d.score) : 95);
  const cutoff = Number(userPrefs.riskCutoff || 75);
  const rawList = Array.isArray(d.checks) ? d.checks.slice() : [];

  const hasL11 = rawList.some((c) => c && typeof c === 'object' && /l11|sybil|block[\s-]*0/i.test((c.label || '') + ' ' + (c.detail || '')));
  if (!hasL11) {
    const l11Ok = d.layer11_sybil_clean !== undefined ? Boolean(d.layer11_sybil_clean) : (score >= cutoff);
    rawList.push({
      label: 'L11 • Block-0 Sybil Cluster',
      detail: l11Ok ? '0 Bundled Genesis Snipers Detected' : 'Block-0 Sybil / Bundled Cluster Flagged',
      passed: l11Ok
    });
  }

  let sybilFailed = false;
  let whaleLpFailed = false;
  for (const c of rawList) {
    if (c && typeof c === 'object' && c.passed === false) {
      const txt = (c.label || '') + ' ' + (c.detail || '');
      if (/l11|sybil|block[\s-]*0/i.test(txt)) sybilFailed = true;
      if (/liq|lp|whale|dump|holder|velocity/i.test(txt)) whaleLpFailed = true;
    }
  }

  const isRisky = (score < cutoff) ||
    (userPrefs.block0SybilAutoWarn && sybilFailed) ||
    (userPrefs.whaleLpRugAlert && whaleLpFailed);

  const col = isRisky ? '#f87171' : '#14f195';
  if (isRisky) {
    rawList.sort((a, b) => Number(Boolean(a && a.passed)) - Number(Boolean(b && b.passed)));
  }

  const rawChecks = rawList.slice(0, 5).map((c) => {
    if (typeof c === 'string') return escapeHtml(c);
    return (c.passed ? '✅ ' : '🚨 ') + escapeHtml((c.label || c.name || 'Layer') + ': ' + (c.detail || c.status || ''));
  });
  const symPrefix = d.symbol ? (escapeHtml(String(d.symbol).replace(/^\$/, '')) + ' • ') : '';
  out.innerHTML =
    `<div style="color:${col};font-weight:900;font-size:11.3px;">${symPrefix}SHIELD SCORE: ${score}/100 • ${escapeHtml(d.verdict || '11-LAYER VERIFIED')}</div>` +
    `<div style="color:#cbd5e1;margin-top:3px;">${rawChecks.join('<br>')}</div>`;

  if (topBanner && topBannerTxt) {
    if (isRisky && userPrefs.topBannerAlert) {
      topBannerTxt.textContent = `🚨 ${d.symbol ? ('$' + String(d.symbol).replace(/^\$/, '') + ' ') : ''}Risk ${score}/100 (Cutoff ${cutoff}/100)`;
      topBanner.classList.add('show');
    } else {
      topBanner.classList.remove('show');
    }
  }

  if (isRisky && allowSound !== false) {
    playPopupWarningChime(false);
  }
}

async function auditMintNow(mintOverride) {
  const inp = document.getElementById('ext-mint-inp');
  const out = document.getElementById('ext-mint-out');
  const mint = (mintOverride || (inp ? inp.value : '') || '').trim();
  if (!mint) {
    out.style.display = 'block';
    out.innerHTML = '<span style="color:#fde047;">⚠️ Paste a Solana token mint address first.</span>';
    return;
  }
  if (inp) inp.value = mint;
  try { localStorage.setItem('ext_last_mint', mint); } catch (_e) {}
  out.style.display = 'block';
  out.innerHTML = '⏳ Running 11-Layer Helius &amp; Gemini 4 Carbon High Pre-Buy Audit...';

  const bgRes = await sendBgMsg({
    type: 'RRS_SCAN_TOKEN',
    mint,
    forceRefresh: true,
    source: 'popup_scanner_v4.2.0'
  });
  if (bgRes && bgRes.ok !== undefined) {
    if (bgRes.ok === false && OFFLINE_PRESET_MINTS[mint]) {
      renderMintResult(out, OFFLINE_PRESET_MINTS[mint], true);
      return;
    }
    renderMintResult(out, bgRes, true);
    return;
  }

  try {
    const d = await apiFetchJson('/api/scan-token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ mint, source: 'popup_scanner_v4.2.0' })
    });
    renderMintResult(out, d, true);
  } catch (_e) {
    if (OFFLINE_PRESET_MINTS[mint]) {
      renderMintResult(out, OFFLINE_PRESET_MINTS[mint], true);
      return;
    }
    out.innerHTML = '<span style="color:#f87171;">⚠️ Connection error reaching live 11-Layer scanner API.</span>';
  }
}

function renderWalletResult(out, wallet, d) {
  if (!d || d.ok === false) {
    const msg = escapeHtml((d && d.error) || 'Invalid Solana wallet address.');
    out.innerHTML = `<span style="color:#f87171;">⚠️ ${msg}</span>`;
    return;
  }
  const sol = Number(d.user_net_95_sol || d.user_payout_sol || d.total_reclaimable_sol || 0).toFixed(4);
  const usd = Number(d.user_net_95_usd || d.user_payout_usd || d.total_reclaimable_usd || 0).toFixed(2);
  const cnt = Number(d.reclaimable_count !== undefined ? d.reclaimable_count : (d.empty_count || 0));
  const claimHref = `https://rentandrugshield.com/app.html?autoscan=1&wallet=${encodeURIComponent(wallet)}`;
  const claimBtn = document.getElementById('ext-claim-link');
  if (claimBtn) claimBtn.href = claimHref;
  out.innerHTML = `<div style="color:#14f195;font-weight:900;">✅ Found ${cnt} Empty ATAs: +${sol} SOL ($${usd} USD • 95% Net)</div>` +
    `<div style="margin-top:4px;"><a href="${claimHref}" target="_blank" rel="noopener noreferrer" style="color:#fde047;font-weight:900;text-decoration:underline;">⚡ Open Non-Custodial Claim Page ↗</a></div>`;
}

async function scanWalletNow(walletOverride, isSample) {
  const inp = document.getElementById('ext-wallet-inp');
  const out = document.getElementById('ext-wallet-out');
  const wallet = (walletOverride || (inp ? inp.value : '') || '').trim();
  if (!wallet) {
    out.style.display = 'block';
    out.innerHTML = '<span style="color:#fde047;">⚠️ Paste a Solana wallet address first.</span>';
    return;
  }
  if (inp) inp.value = wallet;
  out.style.display = 'block';
  out.innerHTML = '⏳ Scanning Solana Mainnet token accounts (Read-Only)...';

  const bgRes = await sendBgMsg({
    type: 'RRS_SCAN_WALLET',
    wallet,
    isSample: Boolean(isSample)
  });
  if (bgRes && bgRes.ok !== undefined) {
    if (bgRes.ok === false && OFFLINE_PRESET_WALLETS[wallet]) {
      renderWalletResult(out, wallet, OFFLINE_PRESET_WALLETS[wallet]);
      return;
    }
    renderWalletResult(out, wallet, bgRes);
    return;
  }

  try {
    const d = await apiFetchJson('/api/scan-wallet', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ wallet, mode: 'rent', is_sample_test: Boolean(isSample) })
    });
    renderWalletResult(out, wallet, d);
  } catch (_e) {
    if (OFFLINE_PRESET_WALLETS[wallet]) {
      renderWalletResult(out, wallet, OFFLINE_PRESET_WALLETS[wallet]);
      return;
    }
    out.innerHTML = '<span style="color:#f87171;">⚠️ Could not reach wallet rent scanner.</span>';
  }
}

async function refreshLiveWinners() {
  try {
    let d = await sendBgMsg({ type: 'RRS_LIVE_TELEMETRY' });
    if (!d || !Array.isArray(d.live_scanned_coins)) {
      d = await apiFetchJson('/api/live-telemetry');
    }
    const list = document.getElementById('ext-winners-list');
    if (list && d && Array.isArray(d.live_scanned_coins) && d.live_scanned_coins.length > 0) {
      const items = d.live_scanned_coins.filter((c) => Number(c.score) >= 70 && c.status_type !== 'blocked').slice(0, 5);
      if (items.length > 0) {
        list.innerHTML = items.map((c, idx) => {
          const medal = idx === 0 ? '🏆' : (idx === 1 ? '🥈' : (idx === 2 ? '🥉' : '🟢'));
          const cleaned = String(c.dex6_action || '').replace(/^🏆 #1 TOP WINNER: |^🥈 #2 TOP WINNER: |^🥉 #3 TOP WINNER: /, '');
          const clipped = Array.from(cleaned).slice(0, 36).join('');
          const shortAct = escapeHtml(clipped);
          const rUrl = encodeURI(c.receipt_url || 'https://rentandrugshield.com/app.html#live-winners');
          const borderStyle = idx === items.length - 1 ? ' style="border-bottom:none;"' : '';
          return `<div class="ticker-item"${borderStyle}><span>${medal} <b style="color:#14f195;">${escapeHtml(c.symbol || 'TOKEN')}</b> (${shortAct})</span><a class="tx-link" href="${rUrl}" target="_blank" rel="noopener noreferrer">🧾 TX ↗</a></div>`;
        }).join('');
      }
    }
  } catch (_e) {}
}

function applyAutoDetectedMint(detected) {
  if (!detected) return false;
  const badge = document.getElementById('tab-detect-badge');
  if (badge) badge.innerText = '🎯 Auto-Detected Tab Mint!';
  try { localStorage.setItem('ext_last_mint', detected); } catch (_e) {}
  auditMintNow(detected);
  return true;
}

function wireLivePrefsListeners() {
  try {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.onChanged) {
      chrome.storage.onChanged.addListener((changes, area) => {
        if ((area === 'sync' || area === 'local') && changes[PREFS_STORAGE_KEY] && changes[PREFS_STORAGE_KEY].newValue) {
          userPrefs = Object.assign({}, DEFAULT_ALERT_PREFS, changes[PREFS_STORAGE_KEY].newValue);
          writeLocalPrefs(userPrefs);
          renderPrefsForm();
        }
      });
    }
  } catch (_e) {}

  window.addEventListener('storage', (ev) => {
    if (ev && ev.key === PREFS_STORAGE_KEY && ev.newValue) {
      try {
        userPrefs = Object.assign({}, DEFAULT_ALERT_PREFS, JSON.parse(ev.newValue));
        renderPrefsForm();
      } catch (_e) {}
    }
  });
}

document.addEventListener('DOMContentLoaded', async () => {
  await initAlertPrefs();
  wireLivePrefsListeners();

  document.getElementById('ext-audit-btn').addEventListener('click', () => {
    emitTelemetryClick('popup_audit_mint', 'Run 11-Layer Mint Audit');
    auditMintNow();
  });
  document.getElementById('ext-test-winner').addEventListener('click', () => {
    emitTelemetryClick('popup_preset_melnok', 'Preset Scan MELNOK');
    auditMintNow('3ig9E5SQKs8RjVn9EuW1YaprjaMd6dEftG63hBcMpump');
  });
  document.getElementById('ext-test-safe').addEventListener('click', () => {
    emitTelemetryClick('popup_preset_wasted6', 'Preset Scan WASTED6');
    auditMintNow('3wyRvbB6nFD7Y9cuozSXrUajZs1EoJxrcBCDBxwupump');
  });
  document.getElementById('ext-test-rug').addEventListener('click', () => {
    emitTelemetryClick('popup_preset_nvidia_rug', 'Preset Scan Rug NVIDIA');
    auditMintNow('AAL1P7Lyj3sPKwYfRTGCi4VRH73mMrSaeYhE4kitCAwL');
  });
  document.getElementById('ext-scan-wallet-btn').addEventListener('click', () => {
    emitTelemetryClick('popup_scan_wallet', 'Scan Trapped SOL Rent');
    scanWalletNow();
  });
  document.getElementById('ext-demo-whale').addEventListener('click', () => {
    emitTelemetryClick('popup_demo_wallet', 'Test Verified Wallet');
    scanWalletNow(SAMPLE_VERIFIED_WALLET, true);
  });
  document.getElementById('ext-open-app-top').addEventListener('click', () => {
    emitTelemetryClick('popup_open_app_top', 'Open App Top Button');
  });
  document.getElementById('ext-claim-link').addEventListener('click', () => {
    emitTelemetryClick('popup_connect_claim', 'Connect & Claim Rent');
  });

  const infoBtn = document.getElementById('pop-layer-info-btn');
  const infoBox = document.getElementById('pop-layer-info-box');
  infoBtn.addEventListener('click', () => {
    infoBox.classList.toggle('open');
    emitTelemetryClick('popup_11layer_info', 'Popup 11-Layer Info Bubble');
  });
  infoBtn.addEventListener('mouseenter', () => infoBox.classList.add('open'));

  document.getElementById('pop-btn-alerts').addEventListener('click', () => {
    openView('alerts', true);
    emitTelemetryClick('popup_open_alerts', 'Open Popup Alerts Modal');
  });
  document.getElementById('pop-btn-carbon').addEventListener('click', () => {
    openView('carbon', true);
    emitTelemetryClick('popup_open_carbon', 'Open Popup Carbon Cert');
  });
  document.getElementById('pop-btn-rnd').addEventListener('click', () => {
    openView('rnd', true);
    emitTelemetryClick('popup_open_rnd', 'Open Popup 14640h R&D');
  });

  document.getElementById('pop-nav-back').addEventListener('click', () => {
    if (viewHistoryIdx > 0) {
      viewHistoryIdx -= 1;
      openView(viewHistory[viewHistoryIdx], false);
    }
    emitTelemetryClick('popup_nav_back', 'Popup Nav Back');
  });
  document.getElementById('pop-nav-home').addEventListener('click', () => {
    openView('home', true);
    emitTelemetryClick('popup_nav_home', 'Popup Nav Home');
  });
  document.getElementById('pop-nav-fwd').addEventListener('click', () => {
    if (viewHistoryIdx < viewHistory.length - 1) {
      viewHistoryIdx += 1;
      openView(viewHistory[viewHistoryIdx], false);
    }
    emitTelemetryClick('popup_nav_forward', 'Popup Nav Forward');
  });

  const rng = document.getElementById('pop-cutoff-range');
  const num = document.getElementById('pop-cutoff-num');
  const valLbl = document.getElementById('pop-cutoff-val');
  rng.addEventListener('input', () => {
    num.value = rng.value;
    valLbl.textContent = rng.value;
  });
  num.addEventListener('input', () => {
    const c = Math.max(0, Math.min(100, Number(num.value) || 0));
    rng.value = String(c);
    valLbl.textContent = String(c);
  });

  document.getElementById('pop-test-chime').addEventListener('click', () => {
    playPopupWarningChime(true);
    emitTelemetryClick('popup_test_chime', 'Popup Test Chime');
  });

  document.getElementById('pop-save-prefs').addEventListener('click', async () => {
    await persistAlertPrefs({
      riskCutoff: Number(num.value),
      audioChimeAlert: document.getElementById('pop-pref-audio').checked,
      topBannerAlert: document.getElementById('pop-pref-banner').checked,
      block0SybilAutoWarn: document.getElementById('pop-pref-sybil').checked,
      whaleLpRugAlert: document.getElementById('pop-pref-whale').checked
    });
    const savedMsg = document.getElementById('pop-prefs-saved-msg');
    if (savedMsg) {
      savedMsg.style.display = 'block';
      setTimeout(() => { savedMsg.style.display = 'none'; }, 2600);
    }
    emitTelemetryClick('popup_save_prefs', 'Popup Save Alert Preferences');
  });

  document.getElementById('pop-reset-prefs').addEventListener('click', async () => {
    await persistAlertPrefs(DEFAULT_ALERT_PREFS);
    emitTelemetryClick('popup_reset_prefs', 'Popup Reset Alert Preferences');
  });

  document.getElementById('popup-top-alert-dismiss').addEventListener('click', () => {
    document.getElementById('popup-top-alert-banner').classList.remove('show');
  });

  try {
    const savedMint = localStorage.getItem('ext_last_mint');
    if (savedMint && document.getElementById('ext-mint-inp')) {
      document.getElementById('ext-mint-inp').value = savedMint;
    }
  } catch (_e) {}

  let handledByParams = false;
  try {
    const qp = new URLSearchParams(window.location.search || '');
    const paramTabUrl = qp.get('tab_url') || '';
    const paramDom = qp.get('dom_hint') || '';
    const paramMint = qp.get('mint') || '';
    const detectedFromParams = extractMintFromUrl(paramMint) || extractMintFromUrl(paramTabUrl) || extractMintFromDomText(paramDom);
    if (detectedFromParams) {
      handledByParams = applyAutoDetectedMint(detectedFromParams);
    }
  } catch (_e) {}

  if (!handledByParams && typeof chrome !== 'undefined' && chrome.tabs && chrome.tabs.query) {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const firstUrl = (tabs && tabs[0] && tabs[0].url) ? tabs[0].url : '';
      if (firstUrl && firstUrl.indexOf('chrome-extension://') !== 0) {
        const detected = extractMintFromUrl(firstUrl);
        if (detected) {
          applyAutoDetectedMint(detected);
          return;
        }
      }
      chrome.tabs.query({}, (allTabs) => {
        if (!Array.isArray(allTabs)) return;
        for (const t of allTabs) {
          const u = (t && t.url) ? t.url : '';
          if (!u || u.indexOf('chrome-extension://') === 0) continue;
          const detected = extractMintFromUrl(u);
          if (detected) {
            applyAutoDetectedMint(detected);
            return;
          }
        }
      });
    });
  }

  refreshLiveWinners();
  setInterval(refreshLiveWinners, 4500);
});

window.RentShieldPopup = {
  extractMintFromUrl,
  extractMintFromDomText,
  auditMintNow,
  scanWalletNow,
  refreshLiveWinners,
  openView
};
