'use strict';

const API_BASE = 'https://rentandrugshield.com';
const SAMPLE_VERIFIED_WALLET = 'C3FFhG83pda2veVRFwTDNyf1YT2R2U2ZHxcg8pUeMjrC';

function escapeHtml(str) {
  return String(str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function extractMintFromUrl(urlStr) {
  if (!urlStr) return '';
  const m = urlStr.match(/[1-9A-HJ-NP-Za-km-z]{32,44}/g);
  if (!m) return '';
  const ignore = new Set(['So11111111111111111111111111111111111111112']);
  for (const cand of m) {
    if (!ignore.has(cand) && cand.length >= 32) return cand;
  }
  return '';
}

function persistLastMint(mint) {
  if (!mint) return;
  try {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      chrome.storage.local.set({ ext_last_mint: mint });
    }
  } catch (_e) {}
}

async function auditMintNow(mintOverride) {
  const inp = document.getElementById('ext-mint-inp');
  const out = document.getElementById('ext-mint-out');
  const mint = (mintOverride || (inp ? inp.value : '') || '').trim();
  if (!mint) {
    out.style.display = 'block';
    out.innerHTML = '<span style="color:#fde047;">⚠️ Paste a Solana token mint address first.</span>';
    return;
  }
  if (inp) inp.value = mint;
  persistLastMint(mint);
  out.style.display = 'block';
  out.innerHTML = '⏳ Running 10-Layer Pre-Buy Anti-Rug Audit...';
  try {
    const r = await fetch(API_BASE + '/api/scan-token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ mint })
    });
    const d = await r.json();
    if (r.status === 402 || d.payment_required) {
      const introLabel = escapeHtml(d.intro_label || '10¢ (30-Day Introductory Price, Reg. 25¢)');
      out.innerHTML =
        '<div style="color:#fde047;font-weight:900;font-size:11px;">🔒 Free Scan Used • Unlock Full 10-Layer Audit</div>' +
        '<div style="color:#cbd5e1;margin-top:3px;">' + introLabel + ' or $1.99 Unlimited Pass</div>' +
        '<div style="margin-top:5px;"><a href="' + API_BASE + '/app.html?mint=' + encodeURIComponent(mint) + '" target="_blank" rel="noopener noreferrer" style="color:#14f195;font-weight:900;text-decoration:underline;">⚡ Unlock on RentAndRugShield.com ↗</a></div>';
      return;
    }
    const score = (d.safety_score !== undefined) ? d.safety_score : ((d.score !== undefined) ? d.score : 95);
    const col = score >= 75 ? '#14f195' : '#f87171';
    const rawChecks = Array.isArray(d.checks) ? d.checks.slice(0, 4).map((c) => {
      if (typeof c === 'string') return escapeHtml(c);
      return (c.passed ? '✅ ' : '🚨 ') + escapeHtml((c.label || c.name || 'Layer') + ': ' + (c.detail || c.status || ''));
    }) : [];
    out.innerHTML = '<div style="color:' + col + ';font-weight:900;font-size:11.5px;">SHIELD SCORE: ' + Number(score) + '/100 • ' + escapeHtml(d.verdict || 'VERIFIED') + '</div>' +
      '<div style="color:#cbd5e1;margin-top:3px;">' + rawChecks.join('<br>') + '</div>';
  } catch (_e) {
    out.innerHTML = '<span style="color:#fde047;">⚡ Open full scanner at <a href="' + API_BASE + '/app.html?mint=' + encodeURIComponent(mint) + '" target="_blank" rel="noopener noreferrer" style="color:#14f195;font-weight:900;">rentandrugshield.com ↗</a></span>';
  }
}

async function scanWalletNow(walletOverride, isSample) {
  const inp = document.getElementById('ext-wallet-inp');
  const out = document.getElementById('ext-wallet-out');
  const wallet = (walletOverride || (inp ? inp.value : '') || '').trim();
  if (!wallet) {
    out.style.display = 'block';
    out.innerHTML = '<span style="color:#fde047;">⚠️ Paste a Solana wallet address first.</span>';
    return;
  }
  if (inp) inp.value = wallet;
  out.style.display = 'block';
  out.innerHTML = '⏳ Scanning Solana Mainnet token accounts (Read-Only)...';
  try {
    const r = await fetch(API_BASE + '/api/scan-wallet', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ wallet, mode: 'rent', is_sample_test: Boolean(isSample) })
    });
    const d = await r.json();
    const sol = Number(d.user_net_95_sol || d.user_payout_sol || d.total_reclaimable_sol || 0).toFixed(4);
    const usd = Number(d.user_net_95_usd || d.user_payout_usd || d.total_reclaimable_usd || 0).toFixed(2);
    const cnt = Number(d.reclaimable_count || d.empty_count || 0);
    out.innerHTML = '<div style="color:#14f195;font-weight:900;">✅ Found ' + cnt + ' Empty ATAs: +' + sol + ' SOL ($' + usd + ' USD • 95% Net)</div>' +
      '<div style="margin-top:4px;"><a href="' + API_BASE + '/app.html?autoscan=1&wallet=' + encodeURIComponent(wallet) + '" target="_blank" rel="noopener noreferrer" style="color:#fde047;font-weight:900;text-decoration:underline;">⚡ Open Non-Custodial Claim Page ↗</a></div>';
  } catch (_e) {
    out.innerHTML = '<span style="color:#fde047;">⚡ Scan directly on <a href="' + API_BASE + '/app.html?autoscan=1&wallet=' + encodeURIComponent(wallet) + '" target="_blank" rel="noopener noreferrer" style="color:#14f195;font-weight:900;">rentandrugshield.com ↗</a></span>';
  }
}

async function refreshLiveWinners() {
  try {
    const r = await fetch(API_BASE + '/api/live-telemetry');
    if (!r.ok) return;
    const d = await r.json();
    const list = document.getElementById('ext-winners-list');
    if (list && Array.isArray(d.live_scanned_coins) && d.live_scanned_coins.length > 0) {
      list.innerHTML = d.live_scanned_coins.filter(c => Number(c.score) >= 70 && c.status_type !== 'blocked').slice(0, 5).map((c, idx) => {
        const medal = idx === 0 ? '🏆' : (idx === 1 ? '🥈' : (idx === 2 ? '🥉' : '🟢'));
        const shortAct = escapeHtml(String(c.dex6_action || '').replace(/^🏆 #1 TOP WINNER: |^🥈 #2 TOP WINNER: |^🥉 #3 TOP WINNER: /, '').slice(0, 36));
        const mintParam = encodeURIComponent(String(c.mint || ''));
        const safeUrl = API_BASE + '/app.html' + (mintParam ? ('?mint=' + mintParam) : '');
        return '<div class="ticker-item"><span>' + medal + ' <b style="color:#14f195;">' + escapeHtml(c.symbol || 'TOKEN') + '</b> (' + shortAct + ')</span><a class="tx-link" href="' + safeUrl + '" target="_blank" rel="noopener noreferrer">🧾 Audit ↗</a></div>';
      }).join('');
    }
  } catch (_e) {}
}

document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('ext-audit-btn').addEventListener('click', () => auditMintNow());
  document.getElementById('ext-test-winner').addEventListener('click', () => auditMintNow('3ig9E5SQKs8RjVn9EuW1YaprjaMd6dEftG63hBcMpump'));
  document.getElementById('ext-test-safe').addEventListener('click', () => auditMintNow('3wyRvbB6nFD7Y9cuozSXrUajZs1EoJxrcBCDBxwupump'));
  document.getElementById('ext-test-rug').addEventListener('click', () => auditMintNow('AAL1P7Lyj3sPKwYfRTGCi4VRH73mMrSaeYhE4kitCAwL'));
  document.getElementById('ext-scan-wallet-btn').addEventListener('click', () => scanWalletNow());
  document.getElementById('ext-demo-whale').addEventListener('click', () => scanWalletNow(SAMPLE_VERIFIED_WALLET, true));

  if (typeof chrome !== 'undefined' && chrome.tabs && chrome.tabs.query) {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs && tabs[0] && tabs[0].url) {
        const detected = extractMintFromUrl(tabs[0].url);
        if (detected) {
          const badge = document.getElementById('tab-detect-badge');
          if (badge) badge.innerText = '🎯 Auto-Detected Tab Mint!';
          auditMintNow(detected);
        }
      }
    });
  }
  refreshLiveWinners();
  setInterval(refreshLiveWinners, 10000);
});
