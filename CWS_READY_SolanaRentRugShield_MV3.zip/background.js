'use strict';

const OFFICIAL_ORIGIN = 'https://rentandrugshield.com';

chrome.runtime.onInstalled.addListener((details) => {
  if (chrome.action && chrome.action.setBadgeBackgroundColor) {
    chrome.action.setBadgeBackgroundColor({ color: '#10b981' });
  }
  if (chrome.storage && chrome.storage.local) {
    chrome.storage.local.set({
      rrs_api_base: OFFICIAL_ORIGIN,
      rrs_installed_version: chrome.runtime.getManifest().version,
      rrs_install_reason: details && details.reason ? details.reason : 'install'
    });
  }
});

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg && msg.type === 'RRS_EXTENSION_HEALTH') {
    sendResponse({
      ok: true,
      api_base: OFFICIAL_ORIGIN,
      version: chrome.runtime.getManifest().version
    });
    return false;
  }
  return false;
});
